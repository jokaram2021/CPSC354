Jonathan Karam
CPSC 354
PA3

Topics
- Programming language syntax and semantics
- Functional programming concepts
- Lambda calculus and expression evaluation
- Abstract reduction systems
- Formal reasoning about programs

Contents
- Source code for assignments
- Written explanations and reports
- Supporting files and examples


