import sys
from lark import Lark, Transformer, Tree
import lark
import os


# print(f"Python version: {sys.version}")
# print(f"Lark version: {lark.__version__}")

#  run/execute/interpret source code
def interpret(source_code):
    cst = parser.parse(source_code)
    ast = LambdaCalculusTransformer().transform(cst)
    result_ast = evaluate(ast)
    result = linearize(result_ast)
    return result


# convert concrete syntax to CST
parser = Lark(open("grammar.lark").read(), parser='lalr')


# convert CST to AST
class LambdaCalculusTransformer(Transformer):

    def lam(self, args):
        name, body = args
        return ('lam', str(name), body)

    def sub(self, args):
        operand1, operand2 = args
        return ('sub', operand1, operand2)

    def add(self, args):
        operand1, operand2 = args
        return ('add', operand1, operand2)

    def mult(self, args):
        # new_args = [(arg.data, arg.children[0]) if isinstance(arg, Tree) and arg.data == 'int' else arg for arg in args]
        operand1, operand2 = args
        return ('mult', operand1, operand2)

    def neg(self, args):
        operand, = args
        return ('neg', operand)

    def ite(self, args):
        condition, then_branch, else_branch = args
        return ('ite', condition, then_branch, else_branch)

    def eq(self, args):
        operand1, operand2 = args
        return ('eq', operand1, operand2)

    def leq(self, args):
        operand1, operand2 = args
        return ('leq', operand1, operand2)

    def let(self, args):
        name, value, body = args
        return ('let', str(name), value, body)

    def rec(self, args):
        name, value, body = args
        return ('rec', name, value, body)

    def prog(self, args):
        if len(args) == 1:
            return args[0]
        result = ('prog', args[0], args[1])
        for expr in args[2:]:
            result = ('prog', result, expr)
        return result

    def hd(self, args):
        operand, = args
        return ('hd', operand)

    def cons(self, args):
        head, tail = args
        return ('cons', head, tail)

    def nil(self, args):
        return ('nil',)

    def tl(self, args):
        operand, = args
        return ('tl', operand)


    def app(self, args):
        # new_args = [(arg.data, arg.children[0]) if isinstance(arg, Tree) and arg.data == 'int' else arg for arg in args]
        return ('app', *args)

    def var(self, args):
        token, = args
        return ('var', str(token))

    def number(self, args):
        token, = args
        return ('number', float(token))


# reduce AST to normal form
letrec_env = {}


# reduce AST to normal form
def evaluate(tree):
    if tree[0] == 'app':
        e1 = evaluate(tree[1])
        if e1[0] == 'lam':
            body = e1[2]
            name = e1[1]
            arg = tree[2]
            rhs = substitute(body, name, arg)
            result = evaluate(rhs)
        else:
            result = ('app', e1, tree[2])
    elif tree[0] == 'sub':
        e1 = evaluate(tree[1])
        e2 = evaluate(tree[2])
        if e1[0] == 'number' and e2[0] == 'number':
            result = ('number', e1[1] - e2[1])
        else:
            result = ('sub', e1, e2)
    elif tree[0] == 'add':
        e1 = evaluate(tree[1])
        e2 = evaluate(tree[2])
        if e1[0] == 'number' and e2[0] == 'number':
            result = ('number', e1[1] + e2[1])
        else:
            result = ('add', e1, e2)
    elif tree[0] == 'mult':
        e1 = evaluate(tree[1])
        e2 = evaluate(tree[2])
        if e1[0] == 'number' and e2[0] == 'number':
            result = ('number', e1[1] * e2[1])
        else:
            result = ('mult', e1, e2)
    elif tree[0] == 'neg':
        e1 = evaluate(tree[1])
        if e1[0] == 'number':
            result = ('number', e1[1] * -1)
        else:
            result = ('neg', e1)
    elif tree[0] == 'ite':
        condition = evaluate(tree[1])
        if condition[0] == 'number':
            # In lambda calculus, 0 is false, non-zero is true
            if condition[1] != 0.0:
                result = evaluate(tree[2])  # then branch
            else:
                result = evaluate(tree[3])  # else branch
        else:
            # Condition not fully evaluated, keep the if-then-else structure
            result = ('ite', condition, tree[2], tree[3])
    elif tree[0] == 'eq':
        e1 = evaluate(tree[1])
        e2 = evaluate(tree[2])

        # number == number
        if e1[0] == 'number' and e2[0] == 'number':
            result = ('number', 1.0 if e1[1] == e2[1] else 0.0)

        # # == #
        elif e1[0] == 'nil' and e2[0] == 'nil':
            result = ('number', 1.0)

        # # == cons(...) or cons(...) == #
        elif (e1[0] == 'nil' and e2[0] == 'cons') or (e1[0] == 'cons' and e2[0] == 'nil'):
            result = ('number', 0.0)

        # cons(h1, t1) == cons(h2, t2)  (structural list equality)
        elif e1[0] == 'cons' and e2[0] == 'cons':
            head_eq = evaluate(('eq', e1[1], e2[1]))
            if head_eq[0] == 'number' and head_eq[1] == 0.0:
                result = ('number', 0.0)
            else:
                tail_eq = evaluate(('eq', e1[2], e2[2]))
                result = tail_eq  # tail_eq is ('number', 1.0) or ('number', 0.0)

        # other stuff: leave as unevaluated equality
        else:
            result = ('eq', e1, e2)

    elif tree[0] == 'leq':
        e1 = evaluate(tree[1])
        e2 = evaluate(tree[2])
        if e1[0] == 'number' and e2[0] == 'number':
            result = ('number', e1[1] <= e2[1])
        else:
            result = ('leq', e1, e2)
    elif tree[0] == 'let':
        # let x = e1 in e2: evaluate e1, then substitute it into e2 and evaluate
        name = tree[1]
        value = evaluate(tree[2])  # Evaluate the value being bound
        body = tree[3]
        # Substitute the evaluated value into the body
        substituted_body = substitute(body, name, value)
        result = evaluate(substituted_body)
    elif tree[0] == 'rec':
        name = tree[1]
        value = evaluate(tree[2])  # Evaluate the value being bound (often a lambda)
        body = tree[3]
        # Temporarily extend the recursive environment so that 'name' is bound in its own body
        old_binding = letrec_env.get(name)
        letrec_env[name] = value
        try:
            result = evaluate(body)
        finally:
            if old_binding is None:
                del letrec_env[name]
            else:
                letrec_env[name] = old_binding

    elif tree[0] == 'prog':
        e1 = evaluate(tree[1])
        e2 = evaluate(tree[2])
        result = ('prog', e1, e2)

    elif tree[0] == 'hd':
        e1 = evaluate(tree[1])
        if e1[0] == 'cons':
            result = e1[1]
        else:
            result = ('hd', e1)
    elif tree[0] == 'cons':
        head = evaluate(tree[1])
        tail = evaluate(tree[2])
        result = ('cons', head, tail)

    elif tree[0] == 'nil':
        result = tree

    elif tree[0] == 'tl':
        e1 = evaluate(tree[1])
        if e1[0] == 'cons':
            result = e1[2]
        else:
            result = ('tl', e1)

    elif tree[0] == 'var':
        bound_value = letrec_env.get(tree[1])
        if bound_value is not None:
            result = bound_value
        else:
            result = tree
    elif tree[0] == 'number':
        result = tree
    else:
        result = tree
        pass
    return result


# generate a fresh name
# needed eg for \y.x [y/x] --> \z.y where z is a fresh name)
class NameGenerator:
    def __init__(self):
        self.counter = 0

    def generate(self):
        self.counter += 1
        # user defined names start with lower case (see the grammar), thus 'Var' is fresh
        return 'Var' + str(self.counter)


name_generator = NameGenerator()


# for beta reduction (capture-avoiding substitution)
# 'replacement' for 'name' in 'tree'
def substitute(tree, name, replacement):
    # tree [replacement/name] = tree with all instances of 'name' replaced by 'replacement'
    if tree[0] == 'var':
        if tree[1] == name:
            return replacement  # n [r/n] --> r
        else:
            return tree  # x [r/n] --> x
    elif tree[0] == 'lam':
        if tree[1] == name:
            return tree  # \n.e [r/n] --> \n.e
        else:
            fresh_name = name_generator.generate()
            return ('lam', fresh_name, substitute(substitute(tree[2], tree[1], ('var', fresh_name)), name, replacement))
            # \x.e [r/n] --> (\fresh.(e[fresh/x])) [r/n]
    elif tree[0] == 'app':
        return ('app', substitute(tree[1], name, replacement), substitute(tree[2], name, replacement))
    elif tree[0] == 'sub':
        left = substitute(tree[1], name, replacement)
        right = substitute(tree[2], name, replacement)
        return ('sub', left, right)
    elif tree[0] == 'add':
        left = substitute(tree[1], name, replacement)
        right = substitute(tree[2], name, replacement)
        return ('add', left, right)
    elif tree[0] == 'mult':
        left = substitute(tree[1], name, replacement)
        right = substitute(tree[2], name, replacement)
        return ('mult', left, right)
    elif tree[0] == 'neg':
        return ('neg', substitute(tree[1], name, replacement))
    elif tree[0] == 'ite':
        condition = substitute(tree[1], name, replacement)
        then_branch = substitute(tree[2], name, replacement)
        else_branch = substitute(tree[3], name, replacement)
        return ('ite', condition, then_branch, else_branch)
    elif tree[0] == 'eq':
        left = substitute(tree[1], name, replacement)
        right = substitute(tree[2], name, replacement)
        return ('eq', left, right)
    elif tree[0] == 'leq':
        left = substitute(tree[1], name, replacement)
        right = substitute(tree[2], name, replacement)
        return ('leq', left, right)
    elif tree[0] == 'let':
        # let x = e1 in e2: if x == name, don't substitute in e2 (shadowing)
        # otherwise, substitute in both e1 and e2
        let_name = tree[1]
        if let_name == name:
            # Variable is shadowed, only substitute in the value
            value = substitute(tree[2], name, replacement)
            return ('let', let_name, value, tree[3])
        else:
            # Substitute in both value and body
            value = substitute(tree[2], name, replacement)
            body = substitute(tree[3], name, replacement)
            return ('let', let_name, value, body)
    elif tree[0] == 'prog':
        left = substitute(tree[1], name, replacement)
        right = substitute(tree[2], name, replacement)
        return ('prog', left, right)
    elif tree[0] == 'cons':
        head = substitute(tree[1], name, replacement)
        tail = substitute(tree[2], name, replacement)
        return ('cons', head, tail)

    elif tree[0] == 'nil':
        return tree
    elif tree[0] == 'hd':
        return ('hd', substitute(tree[1], name, replacement))

    elif tree[0] == 'tl':
        return ('tl', substitute(tree[1], name, replacement))

    elif tree[0] == 'rec':
        # let x = e1 in e2: if x == name, don't substitute in e2 (shadowing)
        # otherwise, substitute in both e1 and e2
        let_name = tree[1]
        if let_name == name:
            # Variable is shadowed, only substitute in the value
            value = substitute(tree[2], name, replacement)
            return ('rec', let_name, value, tree[3])
        else:
            # Substitute in both value and body
            value = substitute(tree[2], name, replacement)
            body = substitute(tree[3], name, replacement)
            return ('rec', let_name, value, body)
    elif tree[0] == 'number':
        return tree
    else:
        raise Exception('Unknown tree', tree)


def linearize(ast):
    if ast[0] == 'var':
        return ast[1]
    elif ast[0] == 'lam':
        return "(" + "\\" + ast[1] + "." + linearize(ast[2]) + ")"
    elif ast[0] == 'app':
        return "(" + linearize(ast[1]) + " " + linearize(ast[2]) + ")"
    elif ast[0] == 'sub':
        return "(" + linearize(ast[1]) + " - " + linearize(ast[2]) + ")"
    elif ast[0] == 'add':
        return "(" + linearize(ast[1]) + " + " + linearize(ast[2]) + ")"
    elif ast[0] == 'mult':
        return "(" + linearize(ast[1]) + " * " + linearize(ast[2]) + ")"
    elif ast[0] == 'neg':
        return "(" + "-" + linearize(ast[1]) + ")"
    elif ast[0] == 'ite':
        return "(if " + linearize(ast[1]) + " then " + linearize(ast[2]) + " else " + linearize(ast[3]) + ")"
    elif ast[0] == 'eq':
        return "(" + linearize(ast[1]) + " == " + linearize(ast[2]) + ")"
    elif ast[0] == "leq":
        return "(" + linearize(ast[1]) + " <= " + linearize(ast[2]) + ")"
    elif ast[0] == "let":
        return "let " + ast[1] + " = " + linearize(ast[2]) + " in " + linearize(ast[3])
    elif ast[0] == "rec":
        return "rec " + ast[1] + " = " + linearize(ast[2]) + " in " + linearize(ast[3])
    elif ast[0] == 'prog':
        return linearize(ast[1]) + " ;; " + linearize(ast[2])
    elif ast[0] == 'hd':
        return "(" + "hd " + linearize(ast[1]) + ")"
    elif ast[0] == 'tl':
        return "(" + "tl " + linearize(ast[1]) + ")"

    elif ast[0] == 'cons':
        return "(" + linearize(ast[1]) + " : " + linearize(ast[2]) + ")"
    elif ast[0] == 'nil':
        return "#"
    elif ast[0] == 'number':
        return str(ast[1])
    else:
        return ast


def main():
    import sys
    if len(sys.argv) != 2:
        # print("Usage: python interpreter.py <filename or expression>", file=sys.stderr)
        sys.exit(1)

    input_arg = sys.argv[1]

    if os.path.isfile(input_arg):
        # If the input is a valid file path, read from the file
        with open(input_arg, 'r') as file:
            expression = file.read()
    else:
        # Otherwise, treat the input as a direct expression
        expression = input_arg

    result = interpret(expression)
    print(f"\033[95m{result}\033[0m")


if __name__ == "__main__":
    main()